Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/dynamic-dependent-select-box-using-jquery-ajax-php/

============ Instruction ============
1. Create a database called location_db at phpMyAdmin and import the "location_db_tables.sql" file into this database.
2. Open the dbConfig.php file and modify the $dbHost, $dbUsername, $dbPassword, and $dbName variables value with your database credentials.
3. Open the "index.php" file on the browser and test functionality.


============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/dynamic-dependent-select-box-using-jquery-ajax-php/#respond